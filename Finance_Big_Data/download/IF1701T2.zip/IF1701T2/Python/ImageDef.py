# -*- coding: utf-8 -*-
# High valence
IMAGES_HV = [
'P046.bmp',
'P047.bmp',
'P053.bmp',
'P060.bmp',
'P061.bmp',
'P062.bmp',
'P063.bmp',
'P064.bmp',
'P065.bmp',
'P067.bmp',
'P070.bmp',
'P071.bmp',
'P072.bmp',
'P084.bmp',
'P087.bmp',
'P088.bmp',
'P091.bmp',
'P108.bmp',
'P109.bmp',
'P110.bmp'
]

# Neutral
IMAGES_NT = [
'N001.bmp',
'N009.bmp',
'N010.bmp',
'N011.bmp',
'N013.bmp',
'N015.bmp',
'N017.bmp',
'N019.bmp',
'N022.bmp',
'N024.bmp',
'N026.bmp',
'N027.bmp',
'N028.bmp',
'N030.bmp',
'N033.bmp',
'N034.bmp',
'N067.bmp',
'N094.bmp',
'N096.bmp',
'N108.bmp'
]

# Low valence
IMAGES_LV = [
'A041.bmp',
'A050.bmp',
'A075.bmp',
'A083.bmp',
'A084.bmp',
'A095.bmp',
'A098.bmp',
'A099.bmp',
'A100.bmp',
'A104.bmp',
'A107.bmp',
'H022.bmp',
'H025.bmp',
'H037.bmp',
'H038.bmp',
'H041.bmp',
'H064.bmp',
'H077.bmp',
'H081.bmp',
'H083.bmp'
]
